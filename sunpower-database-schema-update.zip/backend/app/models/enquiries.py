"""Incoming enquiries, including unqualified website leads."""

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, ForeignKeyConstraint, Index, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, IdMixin, TimestampMixin


class Enquiry(IdMixin, TimestampMixin, Base):
    __tablename__ = "enquiries"
    __table_args__ = (
        CheckConstraint("status IN ('new', 'contacted', 'qualified', 'unqualified', 'converted', 'closed')", name="status_allowed"),
        CheckConstraint("source IN ('website', 'phone', 'referral', 'walk_in', 'other')", name="source_allowed"),
        CheckConstraint("site_id IS NULL OR customer_id IS NOT NULL", name="site_requires_customer"),
        CheckConstraint("phone_e164 IS NULL OR phone_e164 ~ '^\\+[1-9][0-9]{7,14}$'", name="phone_e164"),
        ForeignKeyConstraint(["site_id", "customer_id"], ["sites.id", "sites.customer_id"], ondelete="RESTRICT", name="fk_enquiry_site_customer_match"),
        UniqueConstraint("id", "site_id", name="uq_enquiries_id_site"),
        Index("ix_enquiries_status_created_at", "status", "created_at"),
        Index("ix_enquiries_phone_e164", "phone_e164"),
        Index("uq_enquiries_idempotency_key", "idempotency_key", unique=True, postgresql_where=text("idempotency_key IS NOT NULL")),
    )

    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"))
    site_id: Mapped[int | None] = mapped_column(BigInteger)
    contact_name: Mapped[str] = mapped_column(String(150), nullable=False)
    phone_raw: Mapped[str] = mapped_column(String(40), nullable=False)
    phone_e164: Mapped[str | None] = mapped_column(String(16))
    email: Mapped[str | None] = mapped_column(String(255))
    source: Mapped[str] = mapped_column(String(20), nullable=False, server_default="website")
    status: Mapped[str] = mapped_column(String(20), nullable=False, server_default="new")
    notes: Mapped[str | None] = mapped_column(Text)
    idempotency_key: Mapped[str | None] = mapped_column(String(100))
