"""Customer support tickets, charges, and technician work logs."""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, ForeignKeyConstraint, Index, Integer, Numeric, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, IdMixin, TimestampMixin


class SupportTicket(IdMixin, TimestampMixin, Base):
    __tablename__ = "support_tickets"
    __table_args__ = (
        CheckConstraint("status IN ('open', 'assigned', 'in_progress', 'waiting_customer', 'resolved', 'closed', 'cancelled')", name="status_allowed"),
        CheckConstraint("priority IN ('low', 'normal', 'high', 'urgent')", name="priority_allowed"),
        CheckConstraint("NOT under_warranty OR warranty_id IS NOT NULL", name="warranty_decision_has_warranty"),
        ForeignKeyConstraint(["site_id", "customer_id"], ["sites.id", "sites.customer_id"], ondelete="RESTRICT", name="fk_ticket_site_customer_match"),
        Index("ix_support_tickets_customer_status", "customer_id", "status"),
        Index("ix_support_tickets_site_id", "site_id"),
        Index("uq_support_tickets_idempotency_key", "idempotency_key", unique=True, postgresql_where=text("idempotency_key IS NOT NULL")),
    )

    ticket_number: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False)
    site_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    warranty_id: Mapped[int | None] = mapped_column(ForeignKey("warranties.id", ondelete="RESTRICT"))
    faulty_serial_unit_id: Mapped[int | None] = mapped_column(ForeignKey("serialized_units.id", ondelete="RESTRICT"))
    status: Mapped[str] = mapped_column(String(24), nullable=False, server_default="open")
    priority: Mapped[str] = mapped_column(String(12), nullable=False, server_default="normal")
    under_warranty: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    issue_description: Mapped[str] = mapped_column(Text, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(100))
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=text("now()"), nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TicketCharge(IdMixin, TimestampMixin, Base):
    __tablename__ = "ticket_charges"
    __table_args__ = (
        CheckConstraint("charge_type IN ('part', 'labour')", name="charge_type_allowed"),
        CheckConstraint("cost_amount >= 0 AND customer_price >= 0", name="amounts_nonnegative"),
        CheckConstraint("(charge_type = 'part' AND product_id IS NOT NULL) OR (charge_type = 'labour' AND product_id IS NULL AND replacement_unit_id IS NULL)", name="charge_type_product_consistency"),
        CheckConstraint("NOT covered_by_warranty OR customer_price = 0", name="warranty_covered_no_customer_charge"),
        ForeignKeyConstraint(["replacement_unit_id", "product_id"], ["serialized_units.id", "serialized_units.product_id"], ondelete="RESTRICT", name="fk_ticket_charge_replacement_product"),
        Index("ix_ticket_charges_ticket_id", "ticket_id"),
    )

    ticket_id: Mapped[int] = mapped_column(ForeignKey("support_tickets.id", ondelete="CASCADE"), nullable=False)
    charge_type: Mapped[str] = mapped_column(String(10), nullable=False)
    product_id: Mapped[int | None] = mapped_column(ForeignKey("products.id", ondelete="RESTRICT"))
    replacement_unit_id: Mapped[int | None] = mapped_column(BigInteger)
    description: Mapped[str | None] = mapped_column(String(240))
    cost_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False, server_default="0")
    customer_price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False, server_default="0")
    covered_by_warranty: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))


class TicketWorkLog(IdMixin, TimestampMixin, Base):
    __tablename__ = "ticket_work_logs"
    __table_args__ = (CheckConstraint("work_minutes >= 0", name="work_minutes_nonnegative"), Index("ix_ticket_work_logs_ticket_created", "ticket_id", "created_at"))

    ticket_id: Mapped[int] = mapped_column(ForeignKey("support_tickets.id", ondelete="CASCADE"), nullable=False)
    technician_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    work_notes: Mapped[str] = mapped_column(Text, nullable=False)
    work_minutes: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
