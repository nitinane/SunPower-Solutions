"""Installation jobs, technician assignments, and private evidence metadata."""

from datetime import datetime

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, ForeignKeyConstraint, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, IdMixin, TimestampMixin


class InstallationJob(IdMixin, TimestampMixin, Base):
    __tablename__ = "installation_jobs"
    __table_args__ = (
        CheckConstraint("status IN ('planned', 'scheduled', 'in_progress', 'completed', 'cancelled')", name="status_allowed"),
        ForeignKeyConstraint(["order_id", "site_id"], ["orders.id", "orders.site_id"], ondelete="RESTRICT", name="fk_job_order_site_match"),
        Index("ix_installation_jobs_scheduled_status", "scheduled_at", "status"),
    )

    order_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    site_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, server_default="planned")
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    completion_notes: Mapped[str | None] = mapped_column(Text)


class JobTechnician(IdMixin, TimestampMixin, Base):
    __tablename__ = "job_technicians"
    __table_args__ = (
        UniqueConstraint("job_id", "technician_id", name="uq_job_technician"),
        Index("ix_job_technicians_technician_id", "technician_id"),
    )

    job_id: Mapped[int] = mapped_column(ForeignKey("installation_jobs.id", ondelete="CASCADE"), nullable=False)
    technician_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    assigned_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))


class InstallationEvidence(IdMixin, TimestampMixin, Base):
    __tablename__ = "installation_evidence"
    __table_args__ = (
        CheckConstraint("evidence_type IN ('photo', 'signature', 'document')", name="evidence_type_allowed"),
        CheckConstraint("file_size_bytes > 0 AND file_size_bytes <= 10485760", name="file_size_limit_10mb"),
        CheckConstraint("content_type IN ('image/jpeg', 'image/png', 'image/webp', 'application/pdf')", name="content_type_allowed"),
        Index("ix_installation_evidence_job_type", "job_id", "evidence_type"),
    )

    job_id: Mapped[int] = mapped_column(ForeignKey("installation_jobs.id", ondelete="CASCADE"), nullable=False)
    uploaded_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    evidence_type: Mapped[str] = mapped_column(String(20), nullable=False)
    storage_key: Mapped[str] = mapped_column(String(500), unique=True, nullable=False)
    content_type: Mapped[str] = mapped_column(String(100), nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    caption: Mapped[str | None] = mapped_column(String(240))
    captured_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
